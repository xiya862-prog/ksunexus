package com.ksunexus.core
object RootManager {
    fun isRootAvailable(): Boolean = runCatching { Runtime.getRuntime().exec(arrayOf("su","-c","id")).inputStream.bufferedReader().readText().contains("uid=0") }.getOrDefault(false)
    fun execute(command: String): String = runCatching { Runtime.getRuntime().exec(arrayOf("su","-c",command)).inputStream.bufferedReader().readText() }.getOrDefault("")
}
