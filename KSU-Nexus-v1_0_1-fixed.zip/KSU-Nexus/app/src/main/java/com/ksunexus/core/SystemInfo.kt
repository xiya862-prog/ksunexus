package com.ksunexus.core
import android.os.Build
object SystemInfo { val model get()=Build.MODEL; val androidVersion get()=Build.VERSION.RELEASE; val sdk get()=Build.VERSION.SDK_INT; val kernel get()=System.getProperty("os.version") ?: "unknown" }
