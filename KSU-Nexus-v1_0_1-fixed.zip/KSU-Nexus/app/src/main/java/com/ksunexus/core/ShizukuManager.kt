package com.ksunexus.core

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuManager {
    const val REQUEST_CODE = 1001

    /** Shizuku 服务是否在运行 */
    fun isRunning(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    /** 本应用是否已获得 Shizuku 授权 */
    fun isGranted(): Boolean = runCatching {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    /** 发起授权请求；成功发起后，本应用会出现在 Shizuku 的授权应用列表里 */
    fun requestPermission() {
        runCatching {
            if (!Shizuku.isPreV11() && !Shizuku.shouldShowRequestPermissionRationale()) {
                Shizuku.requestPermission(REQUEST_CODE)
            }
        }
    }

    fun serverUid(): Int? = runCatching { Shizuku.getUid() }.getOrNull()
    fun serverContext(): String? = runCatching { Shizuku.getSELinuxContext() }.getOrNull()

    fun addPermissionListener(l: Shizuku.OnRequestPermissionResultListener) =
        runCatching { Shizuku.addRequestPermissionResultListener(l) }

    fun removePermissionListener(l: Shizuku.OnRequestPermissionResultListener) =
        runCatching { Shizuku.removeRequestPermissionResultListener(l) }
}
