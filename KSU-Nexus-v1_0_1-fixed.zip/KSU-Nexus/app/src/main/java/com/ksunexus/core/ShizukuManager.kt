package com.ksunexus.core
object ShizukuManager { fun isInstalled()=false; fun isRunning()=false; fun serverUid():Int?=null; fun serverContext():String?=null }
