package com.ksunexus.profile
object ProfileManager { private val profiles=mutableMapOf<String,AppProfile>(); fun get(packageName:String)=profiles[packageName]; fun set(profile:AppProfile){profiles[profile.packageName]=profile} }
