package com.ksunexus.profile
data class AppProfile(val packageName:String,val label:String,val root:Boolean=false,val shizuku:Boolean=false)
