package com.ksunexus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ksunexus.core.RootManager
import com.ksunexus.core.ShizukuManager
import com.ksunexus.core.SystemInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexusApp() {
    var root by remember { mutableStateOf<Boolean?>(null) }
    var shizuku by remember { mutableStateOf<Boolean?>(null) }

    // su 检测放到 IO 线程，避免阻塞主线程（弹出授权框时会等待）
    LaunchedEffect(Unit) {
        root = withContext(Dispatchers.IO) { RootManager.isRootAvailable() }
        shizuku = withContext(Dispatchers.IO) { ShizukuManager.isRunning() }
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("KSU Nexus") }) }) { padding ->
            Column(
                Modifier.padding(padding).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Unified Privilege Manager", style = MaterialTheme.typography.titleMedium)
                StatusCard(
                    "KernelSU / Root",
                    when (root) { null -> "Checking…"; true -> "Active"; false -> "Unavailable" }
                )
                StatusCard(
                    "Shizuku",
                    when (shizuku) { null -> "Checking…"; true -> "Running"; false -> "Not running" }
                )
                StatusCard("UID 1000", "Detection only")
                StatusCard("UID 2000", "Detection only")
                HorizontalDivider()
                Text("Device", style = MaterialTheme.typography.titleMedium)
                Text(SystemInfo.model)
                Text("Android ${SystemInfo.androidVersion} · SDK ${SystemInfo.sdk}")
                Text("Kernel ${SystemInfo.kernel}")
            }
        }
    }
}

@Composable
private fun StatusCard(title: String, status: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(status)
        }
    }
}
