# KSU Nexus v1.0.0

KernelSU-oriented privilege management front end.

Includes root detection, Shizuku abstraction, device information and app profile model. UID 1000/2000 are represented as detection-only states; this project does not implement signature bypass, exploit-based escalation, or SELinux enforcement bypass.

## 构建 APK
- **Android Studio**：File → Open 本目录，等待 Sync，Build → Build APK(s)。
- **命令行**：已装 JDK 17 + Android SDK 36 时，执行 `gradle :app:assembleDebug`，产物在 `app/build/outputs/apk/debug/`。
- **GitHub Actions**：推送到 GitHub 仓库，Actions → Build APK 下载 artifact。
